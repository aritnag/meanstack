var express = require('express');
var router = express.Router();
var User = require('../models/user');

router.get('/', function (req, res, next) {
    User.findOne({},function(err,doc){
        if(err){
            return res.send('Error!');
        }
        res.render('node',{email:doc.email});
    });
   
});



router.post('/', function(req, res, next) {
    var email = req.body.email;
    console.log(req.body);
    var user = new User({
        firstName : req.body.firstName,
        lastName : req.body.lastName,
        password : req.body.password,
        email : email        
    });
    user.save(function(err,result){
        console.log(result);
    });
    res.redirect('/');    
});

module.exports = router;
