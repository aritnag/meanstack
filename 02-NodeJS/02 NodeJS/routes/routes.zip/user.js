var express = require('express');
var router = express.Router();
var bcrypt = require('bcryptjs');
var jwt =require('jsonwebtoken');
var User = require('../models/user');

router.post('/', function (req, res, next) {
    var user = new User({
        firstName : req.body.firstName,
        lastName : req.body.lastName,
        password : bcrypt.hashSync(req.body.password,10),
        email : req.body.email
    });
    user.save(function(err,result){
    if(err){
        return res.status(500).json({
            title : 'An Error Occured',
            error : err
        })
    }
    res.status(201).json({
        message : 'User is Saved!',
        obj : result
    })
   })
});

router.post('/signin', function (req, res, next) {
    User.findOne({
        email :req.body.email
    },function(err,doc){
        
        if(err){
            console.log(err);
            return res.status(500).json({
                title : 'An Error Occured',
                error : err
            })
        }
        if(!doc){
            return res.status(401).json({
                title : 'Login failed',
                error : {message : 'Invalid Login Credentials'}
            }) 
        }
        if(!bcrypt.compareSync(req.body.password,doc.password)){
            return res.status(401).json({
                title : 'Invalid Password',
                error : {message : 'Invalid Password Credentials'}
            }) 
        }

        //var newtoken=jwt.sign({user : doc},'secret',{expiresIn : 7200});
        res.status(200).json({
            message : 'Successfully Logged IN',
            //token : newtoken,
            userId : doc._id
        })
    })
});


module.exports = router;