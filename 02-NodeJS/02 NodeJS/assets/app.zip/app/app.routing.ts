import {Routes, RouterModule} from '@angular/router';
import { MessageComponent } from './messages/message.component';
import { AuthenticationComponent } from './auth/authentication.component';
import { MessageInputComponent } from './messages/messsage-input.component';
import { AUTH_ROUTES } from './auth/auth.routes';
import { MessagesComponent } from './messages/messages.component';

const APP_ROUTES : Routes =[
    {path : '', redirectTo : '/messages',pathMatch:'full'},
    {path : 'messages' , component : MessagesComponent},
    {path : 'user', component : AuthenticationComponent , children : AUTH_ROUTES}
];

export const Routing = RouterModule.forRoot(APP_ROUTES);