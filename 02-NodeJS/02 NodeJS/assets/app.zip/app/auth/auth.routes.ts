import {Routes} from '@angular/router';
import { SignUpCompnent } from './signup.component';
import { SigninCompnent } from './signin.component';
import { LogoutComponent } from './logout.component';
 
export const AUTH_ROUTES : Routes =[ 
    {path : '',redirectTo : 'signup',pathMatch:'full'},
    {path : 'signup',component:SignUpCompnent},
    {path : 'signin',component:SigninCompnent},
    {path : 'logout',component:LogoutComponent}
];

